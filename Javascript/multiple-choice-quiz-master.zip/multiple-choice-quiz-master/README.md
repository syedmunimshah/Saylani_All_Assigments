## Multiple Choice Quiz 

A simple dynamic Multiple Choice Quiz based on HTML/Javascript. Questions and answers are fetched from JSON file, so its easy to add more questions to the quiz if desired.

Length: 5 questions


![Screenshot1](https://home.uni-leipzig.de/idiv/quiz/screens/screenshot-1.png)

![Screenshot2](https://home.uni-leipzig.de/idiv/quiz/screens/screenshot-2.png)

![Screenshot3](https://home.uni-leipzig.de/idiv/quiz/screens/screenshot-3.png)

