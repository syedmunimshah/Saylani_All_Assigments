//  Question  
// 1. Write a script to greet your website visitor using JS alert 
// box.

// Answer: 
// alert("");

// Question 2. Write a script to display following message on your web 
// page:

// Answer :
// alert("please Enter a Valid Password.");

// Question 3. Write a script to display following message on your web 
// page: (Hint : Use line break)

// Answer :
// \n =>line break ky liye use hota hy.
// var para="Welcom To Js Land....\n Happy Coding";
// alert(para);

// Question 4. Write a script to display following messages in sequence: 

// Answer :
// alert("Welcom To Js Land");
// alert("Happy Coding!\n Happy Coding Happy CodingHappy Coding Happy Coding");

// Question 5. Generate the following message through browser’s 
// developer console:

// Answer :
// console.log("Happy Coding Happy Coding Happy CodingHappy Coding Happy Coding");

// Question
// 6. Make use of alerts in your new/existing HTML & CSS 
// project.

// Answer :
// alert(1);
// alert(2);
// alert(3);



// Chapter 2 Start 



// Question : 1. Declare a variable called username

// Answer: 
// var username;

// Question : 2. Declare a variable called myName & assign to it a string
// that represents your Full Name.

// Answer:
//  var myName;
//  myName = "Full Name";
//  alert(myName);
//  or 
//  var myName="Full Name"
//  alert(myName);

// Question : 3. Write script to
// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box.

// Answer:
// var titled_message ="Hello World";
// alert(titled_message);

// Question : 
// 4. Write a script to save student’s bio data in JS variables and
// show the data in alert boxes.

// Answer:
// var full_Name="Jhone Doe";
// alert(full_Name);

// var Age="15 Year Old";
// alert(Age);

// var Degree="Certified Mobile Application Developer";
// alert(Degree);

// Question : 
// 5. Write a script to display the following alert using one JS
// variable:

// Answer:
// alert("Pizza \n pizz\n piz\n pi \n p");

// Question : 
// 6. Declare a variable called email and assign to it a string that
// represents your Email Address(e.g. example@example.com).
// Show the blow mentioned message in an alert box.(Hint: use
// string concatenation)

// Answer:
// var email=" example@example.com";
// alert("My Emai Is :"+ email);


// Question : 
// 7. Declare a variable called book & give it the value “A
// smarter way to learn JavaScript”. Display the following
// message in an alert box:

// Answer:
// var book= "A smarter \n way to learn JavaScript";
// alert("I am Trying To Learn From The Book" + book);

// Question : 
// 8. Write a script to display this in browser through JS 

// Answer: 
// document.write("! Yah I Can Write HTML Content Here");

// Question : 
// 9. Store following string in a variable and show in alert and
// browser through JS

// Answer: 
// var img="“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”";
// alert(img);


// Chapter 2 end



// Chapter 3 Start 





// Question :
// 1. Declare a variable called age & assign to it your age.Show
// your age in an alert box.

// Answer: 
// var age= 26;
// alert("I Am " + age+ " Year Old");

// Question :

// 2. Declare & initialize a variable to keep track of how many
// times a visitor has visited a web page. Show his/her
// number of visits on your web page. For example: “You
// have visited this site N times”.


// Answer: 

// var track="You have visited this site 14 times";
// alert(track);
// var track="You have visited this site 13 times";
// alert(track);
// var track="You have visited this site 12 times";
// alert(track);
// var track="You have visited this site 11 times";
// alert(track);
// var track="You have visited this site 10 times";
// alert(track);
// var track="You have visited this site 9 times";
// alert(track);
// var track="You have visited this site 8 times";
// alert(track);
// var track="You have visited this site 7 times";
// alert(track);
// var track="You have visited this site 6 times";
// alert(track);
// var track="You have visited this site 5 times";
// alert(track);
// var track="You have visited this site 4 times";
// alert(track);
// var track="You have visited this site 3 times";
// alert(track);
// var track="You have visited this site 2 times";
// alert(track);
// var track="You have visited this site 1 times";
// alert(track);
// var track="Chala ja ";
// alert(track);

// Question :
// 3. Declare a variable called birthYear & assign to it your
// birth year. Show the following message in your browser:

// Answer:
// var birthYear = 1998;
// document.write("My Birth Years Is"+ birthYear +" Data type of My variable is "+ typeof(birthYear));

// Question :
// 4. A visitor visits an online clothing store
// www.xyzClothing.com . Write a script to store in variables
// the following information:
// a. Visitor’s name
// b. Product title
// c. Quantity i.e. how many products a visitor wants to
// order
// Show the following message in your browser: “John
// Doe ordered 5 T-shirt(s) on XYZ Clothing store”.

// Answer:
// var Visitors_Name="John Doe";
// var Quantity="5 T-shirt(s)";
// var Product_title="XYZ Clothing store";

// document.write(Visitors_Name + " ordered "  + Quantity + Product_title);

// Chapter 3 end



// Chapter 4 Start 



// Question :
// Declare 3 variables in one statement.

// Answer:
// var name="Ali", last_Name="Shah", age=26;
// alert(age+ name+last_Name);

// Question :
// 2. Declare 5 legal & 5 illegal variable names.

// Answer:
// Legal Variable Names:
// userName
// _counter
// $price
// myVar
// user123


// Illegal Variable Names:
// 123user (starts with a number)
// my-var (contains a hyphen)
// @username (contains special character other than underscore or dollar sign)
// for (uses a reserved keyword)
// let (uses a reserved keyword)

// Question :

// 3. Display this in your browser
// a) A heading stating “Rules for naming JS variables”
// b) Variable names can only contain ______, ______,
// ______ and ______.
// For example $my_1stVariable
// c) Variables must begin with a ______, ______ or
// _____. For example $name, _name or name
// d) Variable names are case _________
// e) Variable names should not be JS _________

// Answer:

// document.write("Variable names can only contain .numbers. $ and For example $my_1stVariable.");
// document.write("<br>");
// document.write("Variables must begin with a letter, $ or _ For example $name, _name or name");
// document.write("<br>");
// document.write("Variable names are case Sensitive");
// document.write("<br>");
// document.write(" Variable names should not be JS keyword");



// Chapter 4 end



// Chapter 5 Start 

// Question :

// 1. Write a program that take two numbers & add them in a
// new variable. Show the result in your browser.

// Answer:
// var a=3;
// var b=5;
// var add=a+b;
// document.write("Sum Of 3 and 5 is  "+ add);

// Question :
// 2. Repeat task1 for subtraction, multiplication, division &
// modulus.

// Answer:
// document.write("<br>");
// var a=3;
// var b=5;
// var sub=a-b;
// document.write("subtraction Of 3 and 5 is  "+ sub);


// document.write("<br>");
// var a=3;
// var b=5;
// var Mul=a*b;
// document.write("Multiplication Of 3 and 5 is  "+ Mul);


// document.write("<br>");
// var a=3;
// var b=5;
// var modulus=a%b;
// document.write("modulus Of 3 and 5 is  "+ modulus);


// Question :
// 3. Do the following using JS Mathematic Expressions
// a. Declare a variable.
// b. Show the value of variable in your browser like “Value
// after variable declaration is: ??”.
// c. Initialize the variable with some number.
// d. Show the value of variable in your browser like “Initial
// value: 5”.
// e. Increment the variable.
// f. Show the value of variable in your browser like “Value
// after increment is: 6”.
// g. Add 7 to the variable.
// h. Show the value of variable in your browser like “Valueafter addition is: 13”.
// i. Decrement the variable.
// j. Show the value of variable in your browser like “Value
// after decrement is: 12”.
// k. Show the remainder after dividing the variable’s value
// by 3.
// l. Output : “The remainder is : 0”.

// Answer:

// var variable;
// document.write("Value after variable declaration is " + variable);

// document.write("<br>");
// var variable=5;
// document.write("Initial value: " + variable);

// document.write("<br>");
// var variable =5;
// variable++;
// document.write("Value after increment is " + variable);

// document.write("<br>");
// var variable =5;
// variable++;
// var variable1 =7;
// var add=variable + variable1;

// document.write("Value after addition is" + add);
// document.write("<br>");
// add--;
// document.write("Value after addition is :" + add);

// document.write("<br>");
// var remainder=add/3;
// document.write("The remainder is : " + remainder);


// Question :

// 4. Cost of one movie ticket is 600 PKR. Write a script to
// store
// ticket price in a variable & calculate the cost of buying 5
// tickets
// to a movie. Example output:

// Answer:
// var para="Toatal Cost to buy 5 tickets to a movie is";
// var add =600*5;
// document.write(para+"  "+add+"PKR");

// Question :
// 5. Write a script to display multiplication table of any
// number in your browser. E.g

// Answer:
// document.write("<h2>Multiplication Table of 4</h2>");

// for (var i = 1; i <= 10; i++) {
//     var result = 4 * i;
//     document.write("4 x " + i + " = " + result + "<br>");
// }

// Question :
// 6. The Temperature Converter: It’s hot out! Let’s make a
// converter based on the steps here.
// a. Store a Celsius temperature into a variable.
// b. Convert it to Fahrenheit & output “NNoC is NNoF”.
// c. Now store a Fahrenheit temperature into a variable.
// d. Convert it to Celsius & output “NNoF is NNoC”.

// Conversion Formulae:

// Answer:

// Celsius to Fahrenheit conversion formula: (C × 9/5) + 32
// Fahrenheit to Celsius conversion formula: (F - 32) × 5/9

// Store a Celsius temperature
// let celsiusTemperature = 25;

// Convert Celsius to Fahrenheit
// let fahrenheitTemperature = (celsiusTemperature * 9/5) + 32;

// Output the conversion result
// document.write(celsiusTemperature + "°C is " + fahrenheitTemperature + "°F<br>");

// Store a Fahrenheit temperature
// let fahrenheitTemperature2 = 77;

// Convert Fahrenheit to Celsius
// let celsiusTemperature2 = (fahrenheitTemperature2 - 32) * 5/9;

// Output the conversion result
// document.write(fahrenheitTemperature2 + "°F is " + celsiusTemperature2 + "°C");


// Question :
// 7. Write a program to implement checkout process of a
// shopping cart system for an e-commerce website. Store
// the following in variables
// a. Price of item 1
// b. Price of item 2
// c. Ordered quantity of item 1
// d. Ordered Quantity of item 2
// e. Shipping charges

// Compute the total cost & show the receipt in your browser.

// Answer:
// document.write("<h1> Shopping Cart</h1>");

// var item_1=650,item_2=100;
// var Qun_1=3, Qun_2=7;
// var Ship=100;
// var total=item_1*Qun_1+item_2*Qun_2+Ship;
// document.write("Tatal Cost of your order is "+total);

// Question :
// 8. Store total marks & marks obtained by a student in 2
// variables. Compute the percentage & show the result in
// your browser

// Answer:
// document.write("<h1> MarkSheet</h1>");
// var Total_Marks=980;
// var obtained=804;
// var Percentage=(obtained/Total_Marks)*100;

// document.write("<br>");
// document.write("Total marks: " +Total_Marks);

// document.write("<br>");
// document.write("obtained: " +obtained);


// document.write("<br>");
// document.write("Percentage: " +Percentage);

// Question :
// 9. Assume we have 10 US dollars & 25 Saudi Riyals. Write a
// script to convert the total currency to Pakistani Rupees.
// Perform all calculations in a single expression.
// (Exchange rates : 1 US Dollar = 104.80 Pakistani Rupee
// and 1 Saudi Riyal = 28 Pakistani Rupee)

// Answer:
// var total= (10*104.80)+(25*28);
// document.write("<h1> Currency in PKR</h1>");
// document.write("<br> Currency in PKR is: "+total);

// Question :

// Answer:
// let initialValue = 10;

// let totl = ((initialValue + 5) * 10) / 2;

// document.write("Initial Value: " + initialValue + "<br>");
// document.write("Final Result: " + totl);

// Question :
// The Age Calculator: Forgot how old someone is?
// Calculate it!
// a. Store the current year in a variable.
// b. Store their birth year in a variable.
// c. Calculate their 2 possible ages based on the stored
// values.

// Output them to the screen like so: “They are either NN or NN
// years old”.

// Answer:
// document.write("<h1> Age Calculator</h1>");

// const d = new Date();
// let year = d.getFullYear();

// var birthYear = 1998;
// var age = year-birthYear;


// document.write("Current Year:" +year +"<br>" +"Birth Year: "+ birthYear + "<br>Your Age Is: "+age);

// Question :
// 12. The Geometrizer: Calculate properties of a circle.
// a. Store a radius into a variable.

// b. Calculate the circumference based on the radius, and
// output “The circumference is NN”.
// (Hint : Circumference of a circle = 2 π r , π = 3.142)
// Calculate the area based on the radius, and output “The
// area is NN”. (Hint : Area of a circle = π r2, π = 3.142)

// Answer:

var radius = 7; 


var circumference = 2 * Math.PI * radius;
var area = Math.PI * radius * radius;


document.write("The circumference is " + circumference.toFixed(2) + "<br>");
document.write("The area is " + area.toFixed(2));


// Chapter 5 end
